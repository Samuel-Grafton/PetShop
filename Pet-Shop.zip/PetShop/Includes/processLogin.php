<?php

$login = $_POST;

foreach($login as &$entry){
	$entry = dbString($entry);	
}

function dbString($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

/*if($login['username'] == 'admin' && $login['pwd'] == '12345'){
	header('Location: /editForm.php');
	return true;		
} else {
	&$error = echo "<script type='text/javascript'>alert('Your Username or Password is INCORRECT please try again.');</script>";
	return false;
}
*/
?>