<footer>
    <div id="localfriends">
    	<ul>
    		<li><a>Local Services</a></li><br>
    		<li><a>Local Services</a></li><br>
    		<li><a>Local Services</a></li>
    	</ul>
    </div>
    <div id="strHrs">
    	 <p>
    		Store Hours:<br>
        	Mon - Thurs: 8am - 6pm<br>
        	Fri - Sat: 8am - 8pm<br>
        	Sunday: Closed<br>
            12345 Some Street Random City, SA 98765
    	</p>
    </div>
    <div id="log">
    	<a href="LogIn.php">Log In</a>
    </div>
    <div style="clear:both"></div>
</footer>