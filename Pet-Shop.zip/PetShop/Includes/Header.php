<header>
	<a href="index.php"><img src="Images/logo.jpg" alt="Logo" id="logo"></a>
	<nav>
    	<ul>
    		<li><a href="About.php">About Us</a></li>
    		<li><a href="Locate.php">Locate Us</a></li>
    		<li><a href="Grooming.php">Grooming</a></li>
            <li><a href="Contact.php">Contact Us</a></li>       
        </ul> 
    </nav>
</header>