<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation-flex.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<script type="text/javascript" src="Includes/Val.js"></script>
<script type="text/javascript" src="Includes/jquery-1.12.0.min.js"></script>
<script>
	$(document).ready(function () {
    $('#petType').bind('change', function () {
		$('#dogs').hide();
        var value = $(this).val();
        if (value == "dog") {		 
            $('#dogs').show();
        } 
    }).trigger('change');
});
</script>
<script>
	$(document).ready(function(){
		$('#Submit').on('click', function(event){
			event.preventDefault();
			var form = document.getElementById('form');
			if(validate(form) === true) {
			var fName = document.getElementById('fName').value;
			var lName = document.getElementById('lName').value;
			var address = document.getElementById('address').value;
			var city = document.getElementById('city').value;
			var state = document.getElementById('state').value;
			var zip = document.getElementById('zip').value;
			var phoneNumber = document.getElementById('phoneNumber').value;
			var email = document.getElementById('email').value;
			var petType = document.getElementById('petType').value;
			var dogType = document.getElementById('dogType').value;
			var petName = document.getElementById('petName').value;
			var neutSpay = document.getElementById('neutSpay').value;
			var petAge = document.getElementById('petAge').value;
			
			$.ajax({
        		
        		url : 'Includes/processApp.php',
 
       			data : { 
					fName : fName, 
					lName : lName, 
					address : address,
					city : city,
					state : state,
					zip : zip,
					phoneNumber : phoneNumber,
					email : email,
					petType : petType,
					dogType : dogType,
					petName : petName,
					neutSpay : neutSpay,
					petAge : petAge
					},
 
        		type : 'POST',
  
        		success : function() {
            		alert('Thank you! We will contact you soon!');
        		},
 
        		error : function(xhr, status) {
            		alert('Sorry, there was a problem!');
        		},
 
        		/*complete : function(xhr, status) {
            		alert('The request is complete!');
        		}*/
    		});
			} 
		});
	}); 
</script>
<title>Sandy's Pet Shop</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?>
<form method="post" action="Grooming.php" onsubmit="return validate(this)" id="form">
<fieldset class="contact" id="personal">
	<legend>Personal Info:</legend>
		<div class="row">    
            <div class="small-12 medium-4 large-3 columns"> 
            <label for="fName">First Name:</label>       
			<input type="text" size="15" name="fName" id="fName" title="First Name">          
			</div>
            <div class="small-12 medium-3 large-3 columns">
            <label for="lName">Last Name:</label>
			<input type="text" size="15" name="lName" id="lName" title="Last Name">
            </div>
		</div>
            <!-- -->
        <div class="row">
            <div class="small-6 medium-4 large-3 columns">
            <label for="address">Address:</label>
			<input type="text" size="15" name="address" id="address" title="Address">
			</div>
            <div class="small-7 medium-4 large-3 columns">
            <label for="city">City:</label>
			<input type="text" size="15" name="city" id="city" title="City">		
			</div>
            <div class="small-12 medium-2 large-2 columns">
            <label for="state">State:</label>
			<input type="text" size="15" name="state" id="state" title="State" placeholder="CA">
			</div>      
            <div class="small-12 medium-12 large-3 columns">
            <label for="zip">Zip Code</label>
			<input type="text" size="15" name="zip" id="zip" title="Zip Code">
            </div>
        </div>
			<!-- -->
        <div class="row">
            <div class="small-12 medium-4 large-3 columns">
            <label for="phoneNumber">Phone Number:</label>
			<input type="text" size="15" name="phoneNumber" id="phoneNumber" title="Phone Number">
			</div>       	
            <div class="small-12 medium-4 large-3 columns">
            <label for="email">E-mail:</label>
            <input type="email" size="20" name="email" id="email" title="E-mail">
            </div>
        </div>
</fieldset>
<fieldset class="contact" id="petInfo">
	<legend>Pet Info</legend>
        <div class="row">
        	<div class="small-12 medium-expand columns">
				<label for="petType">Type of Pet:</label>
				<select name="petType" id="petType" title="Type of Pet">
            		<option value="0"> Please select...</option>
            		<option value="dog">Dog</option>
                	<option value="cat">Cat</option>
            	</select>
            	</div>
        	<div class="small-12 medium-expand columns" id="dogs">
        		<label for="dogType">Type of Dog:</label>
            	<select name="dogType" id="dogType" title="Type of Dog">
            		<option value="0"> Please select...</option>
                	<option value="poodle">Poodle</option>
                	<option value="pitbull">Pitbull</option>
                	<option value="bulldog">Bulldog</option>
                	<option value="pekingese">Pekingese</option>
            	</select>
            </div>
         </div>
            <!-- -->
            <div class="columns">
			<label for="petName">Pet's Name:</label>
			<input type="text" size="15" name="petName" id="petName" title="Pet Name">
			</div>
            
			<div class="columns">
			<label for="petAge">Pet's Age:</label>
			<input type="text" size="2" name="petAge" id="petAge" title="Pet Age">
            </div>
            <div class="columns">
			<label for="neutSpay">Neutered/Spayed:</label>
			<input type="checkbox" name="neutSpay" id="neutSpay" title="Neutered/Spayed" value="checked">
            </div>
        <div class="float-right">
        	<input type="submit" id="Submit" name="Submit" value="Submit">
        </div>
</fieldset>
</form>
<?php require('Includes\Footer.php');?> 
</div>
</div>
</body>
</html>
