<?php
@$db = new mysqli('localhost','root','pwdpwd','pet_shop');
	if (mysqli_connect_errno())
	{
		echo 'Cannot connect to database: ' . mysqli_connect_error();
	}
	
$_SESSION['previous'] = basename($_SERVER['PHP_SELF']);
	if (isset($_SESSION['previous'])) {
   if (basename($_SERVER['PHP_SELF']) != $_SESSION['previous']) {
        session_destroy();
		header('Location: index.php');
        
   }
}
	
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script type="text/javascript" src="Includes/Val.js"></script>
<script type="text/javascript" src="Includes/jquery-1.12.0.min.js"></script>
<script>
	$(document).ready(function(){
		$('#Submit').on('click', function(event){
			event.preventDefault();
			var form = document.getElementById('form');
			if(validate(form) === true) {
			var fName = document.getElementById('fName').value;
			var lName = document.getElementById('lName').value;
			var address = document.getElementById('address').value;
			var city = document.getElementById('city').value;
			var state = document.getElementById('state').value;
			var zip = document.getElementById('zip').value;
			var phoneNumber = document.getElementById('phoneNumber').value;
			var email = document.getElementById('email').value;
			var petType = document.getElementById('petType').value;
			var breed = document.getElementById('dogType').value;
			var petName = document.getElementById('petName').value;
			var neutSpay = document.getElementById('NeuteredOrSpayed').value;
			var petAge = document.getElementById('petAge').value;
			
			$.ajax({
     
        		url : 'Includes/Update.php',
 
       			data : {
					GroomingID : <?php echo $_POST['GroomingID']; ?>, 
					fName : fName, 
					lName : lName, 
					address : address,
					city : city,
					state : state,
					zip : zip,
					phoneNumber : phoneNumber,
					email : email,
					petType : petType,
					breed : breed,
					petName : petName,
					neutSpay : neutSpay,
					petAge : petAge
					},
 
        		type : 'POST',
  
        		success : function() {
            		alert('Edit Successful.');
					window.location.replace("groomReq.php");
        		},
 
        		error : function(xhr, status) {
            		alert('Sorry, there was a problem!');
        		},
 
        		/*complete : function(xhr, status) {
            		alert('The request is complete!');
        		}*/
    		});
			} 
		});
	}); 
</script> 
<title>Edit Form</title>
</head>
<body>
<div align="center">
<?php require('Includes\processEdit.php');?> 
<form method="post" action="groomReq.php" onsubmit="return validate(this)" id="form">
<table align="center" border="1" width="500">
<?php
echo textEntry('First Name','fName','FirstName',$_POST['FirstName'],15);
echo textEntry('Last Name','lName','LastName',$_POST['LastName'],15);
echo textEntry('Address','address','Address',$_POST['Address'],15);
echo textEntry('City','city','City',$_POST['City'],15);
echo textEntry('State','state','State',$_POST['State'],2);
echo textEntry('Zip','zip','Zip',$_POST['Zip'],15);
echo textEntry('Phone Number','phoneNumber','PhoneNumber',$_POST['PhoneNumber'],15);
echo textEntry('Email','email','Email',$_POST['Email'],15);
echo selectEntry('Pet Type','petType','PetType',$petEntries,$_POST['PetType']);
echo selectEntry('Breed','dogType','Breed',$dogEntries,$_POST['Breed']);
echo textEntry('Pet Name','petName','PetName',$_POST['PetName'],15);
echo checkEntry('Neutrered/Spayed','NeuteredOrSpayed','NeuteredOrSpayed',$_POST['NeuteredOrSpayed']);
echo textEntry('Pet Age','petAge','PetAge',$_POST['PetAge'],2);

$db->close(); 
?>
<tr>
	<td>
		<input type="submit" id="Submit" name="Submit" value="Submit"> 
	</td>
</tr>
</table>
<a align="right" href='Includes/Logout.php'>Log out</a>
</div>
</form>
</body>
</html>