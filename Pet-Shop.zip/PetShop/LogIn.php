<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation-flex.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<script type="text/javascript" src="Includes/jquery-1.12.0.min.js"></script>
<script type="text/javascript" src="Includes/Login.js"></script>
<title>Sandy's Pet Shop</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?> 
<?php 
	if(isset($_POST['username']) && ($_POST['pwd'])) {
		if($_POST['username'] == 'admin' && $_POST['pwd'] == '12345'){
			$_SESSION['login'] = true;
			header('Location: groomReq.php');	
		} else {
			echo "<script type='application/javascript'> alert('Username and/or password are INCORRECT.'); </script>";	
		}
	}
?>
<form method="post" onsubmit="return validate(this)">
  <fieldset class="contact" id="logIn">
  <legend>Employee Log In</legend>
  <div class="row">
  <div class="column">
  <label>Username</label>
  <input type="text" name="username" id="username" title="Username">
  <label>Password</label>
  <input type="password" name="pwd" id="pwd" title="Password">
  <input type="submit" id="Submit" name="Submit" value="Submit">
  </div>
  </div>
  </fieldset>
</form>
<?php require('Includes\Footer.php');?> 
</div>
</div>
</body>
</html>