<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation-flex.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<title>About Us</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?>
<main id="mainContent">
	<div class="divider">
	<img src="Images/turtles.jpg" class="bioPic">
	<p class="innerContent"> Hi this is  a test page to determine if this content will float appropiately with onjunction to the appropiate bio picture. Here is your result thus coming from you coding trying to extend this as much as possible walla walla washington thank you and goodnight.
    </p>
    </div>
	<div class="clearer"></div>
    <div class="divider">
    <img src="Images/turtles.jpg" class="bioPic">
	<p class="innerContent"> Hi this is  a test page to determine if this content will float appropiately with onjunction to the appropiate bio picture. Here is your result thus coming from you coding trying to extend this as much as possible walla walla washington thank you and goodnight.
    </p>
    </div>
	<div class="clearer"></div>
    <div class="divider">
    <img src="Images/turtles.jpg" class="bioPic">
	<p class="innerContent"> Hi this is  a test page to determine if this content will float appropiately with onjunction to the appropiate bio picture. Here is your result thus coming from you coding trying to extend this as much as possible walla walla washington thank you and goodnight.
    </p>
    </div>
	<div class="clearer"></div>
    <div class="divider"></div>
</main>
<?php require('Includes\Footer.php');?>
</div>
</div>
</body>
</html>