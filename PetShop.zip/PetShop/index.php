<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation.min.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<title>Sandy's Pet Shop</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?> 
<main id="mainContent">
  <h1>Welcome to Sandy's Pet Shop!</h1>
  <h5>We are proud to annouce our grandopening!<br> Stop by for some treats catering to both humans and animals alike!</h5>
</main>
<?php require('Includes\Footer.php');?> 
</div>
</div>
</body>
</html>
