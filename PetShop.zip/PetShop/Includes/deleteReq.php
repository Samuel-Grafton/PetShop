<?php
@$db = new mysqli('localhost','root','pwdpwd','pet_shop');
if (mysqli_connect_errno()){
	echo 'Cannot connect to database: ' . mysqli_connect_error();
}
	
$groomingID = $_POST['GroomingID'];
$query = "DELETE FROM grooming WHERE GroomingID = $groomingID";
	
if($db->query($query)){
	echo '<div align="center">Delete Successful</div>';
} else {
	echo '<div align="center">Delete failed</div>';
	echo mysqli_errno($db);
	echo mysqli_error($db);
}
?>