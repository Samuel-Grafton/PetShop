<?php

$checkbox = isset($_POST['neutSpay']) ? $_POST['neutSpay'] : 0 ;
				
$dbEntries = $_POST;
foreach ($dbEntries as &$entry){
	$entry = dbString($entry);
}

@$db = new mysqli('localhost','root','pwdpwd','pet_shop');
if (mysqli_connect_errno()){
	echo 'Cannot connect to database: ' . mysqli_connect_error();
}
	$query = "INSERT INTO grooming
		(FirstName, LastName, Address,
			City, State, Zip, PhoneNumber,
			Email, PetType, PetName, Breed, NeuteredOrSpayed, PetAge)
		VALUES ('" .	$dbEntries['fName'] . "','" .
						$dbEntries['lName'] . "','" .
						$dbEntries['address'] . "','" .
						$dbEntries['city'] . "','" .
						$dbEntries['state'] . "','" .
						$dbEntries['zip'] . "','" .
					 		$dbEntries['phoneNumber'] . "','" .
					 		$dbEntries['email'] . "','" .
						$dbEntries['petType'] . "','" .
					 		$dbEntries['petName'] . "','" .
							$dbEntries['dogType']. "','" .
					 		$checkbox . "','" .
						$dbEntries['petAge'] . "')";


if ($db->query($query)){
	echo '<div align="center">We will contact you ASAP</div>';
} else {
	echo '<div align="center">Insert failed</div>';
}
	
function dbString($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>