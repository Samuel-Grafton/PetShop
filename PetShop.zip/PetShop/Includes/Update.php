<?php

$checkbox = isset($_POST['NeuteredOrSpayed']) ? $_POST['NeuteredOrSpayed'] : 0 ;
				
$dbEntries = $_POST;
foreach ($dbEntries as &$entry){
	$entry = dbString($entry);
}

@$db = new mysqli('localhost','root','pwdpwd','pet_shop');
if (mysqli_connect_errno()){
	echo 'Cannot connect to database: ' . mysqli_connect_error();
} 
		$groomingID = $_POST['GroomingID'];
		$query = "UPDATE grooming
				SET FirstName='" . $dbEntries['fName'] . "',
				LastName='" . $dbEntries['lName'] . "',
				Address='" . $dbEntries['address'] . "',
				City='" . $dbEntries['city'] . "',
				State='" . $dbEntries['state'] . "',
				Zip='" . $dbEntries['zip'] . "',
				PhoneNumber='" . $dbEntries['phoneNumber'] . "',
				Email='" . $dbEntries['email'] . "',
				PetType='" . $dbEntries['petType'] . "',
				Breed='" . $dbEntries['breed'] . "',
				PetName='" . $dbEntries['petName'] . "',
				NeuteredOrSpayed='" . $dbEntries['neutSpay'] . "',
				PetAge='" . $dbEntries['petAge']. "'";
				
				$query .= " WHERE GroomingID = $groomingID";

	if($db->query($query)){
	echo '<div align="center">We will contact you ASAP</div>';
} else {
	echo '<div align="center">Insert failed</div>';
	echo mysqli_errno($db);
	echo mysqli_error($db);
}

function dbString($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>