// JavaScript Document

function validate(form) {
	var userName = form.username.value;
	var pwd = form.pwd.value;	
	
	var errors = [];
	
	if(userName === ''){
		errors[errors.length] = "Please enter a username";	
	}
	
	if(pwd === ''){
		errors[errors.length] = "Please enter a password";	
	}
	
	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function reportErrors(errors){
	var msg = "To Log In you need to...\n";
	for (var i = 0; i<errors.length; i++) {
		var numError = i + 1;
		msg += "\n" + numError + ". " + errors[i];
	}
	alert(msg);
}

