// JavaScript Document
	
var reEmail = /^(\w+[\-\.])*\w+@(\w+\.)+[A-Za-z]+$/;
var reName = /^[A-Za-z]{3,15}$/;
var reState = /^[A-Z]{2}$/;
var reZip = /^\d{5}(\-\d{4})?$/;
var rePhone = /^\(?([2-9]\d\d)\)?[\-\. ]?([2-9]\d\d)[\-\. ]?(\d{4})$/;

function validate(form){
	var firstName = form.fName.value; 
	var lastName = form.lName.value;
	var address = form.address.value;
	var city = form.city.value;
	var state = form.state.value;
	var zipCode = form.zip.value;
	var phone = form.phoneNumber.value; 
	var pet = form.petName.value;
	var opt = form.petType;
	var opt2 = form.dogType; 
	
	var errors = [];

	if (!reName.test(firstName)) {
		errors[errors.length] = "Enter a valid first name.";
	}
	
	if (!reName.test(lastName)) {
		errors[errors.length] = "Enter a valid last name.";
	}
	
	if(address === ''){
		errors[errors.length] = "Enter your address.";
	}
	
	if(city === ''){
		errors[errors.length] = "Enter the city you live in.";	
	}
	
	if (!reState.test(state)) {
		errors[errors.length] = "Enter a valid state appreviation.";
	}
	
	if (!reZip.test(zipCode)) {
		errors[errors.length] = "Enter a valid zip code.";
	}
	
	if(!rePhone.test(phone)) {
		errors[errors.length] = "Enter a valid phone number.";	
	}
	
	if(opt.selectedIndex === 0) {
		errors[errors.length] = "Select your pet's type.";	
	}  
	
	if(opt.selectedIndex === 1 && opt2.selectedIndex === 0) {
			errors[errors.length] = "Select your dog's breed.";
		} 
	
	
	if (!reName.test(pet)){
		errors[errors.length] = "Enter your pet's name.";		
	}
	
	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function reportErrors(errors){
	var msg = "To set an appointment we need you to...\n";
	for (var i = 0; i<errors.length; i++) {
		var numError = i + 1;
		msg += "\n" + numError + ". " + errors[i];
	}
	alert(msg);
}


