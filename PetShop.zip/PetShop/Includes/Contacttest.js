var reEmail = /^(\w+[\-\.])*\w+@(\w+\.)+[A-Za-z]+$/;
var reName = /^[A-Za-z]{3,15}$/;


function validate(form){
	var firstName = form.fName.value; 
	var lastName = form.lName.value;
	var email = form.email.value; 
	var userMsg = document.getElementById("usermsg").value;
	
	var errors = [];

	if (!reName.test(firstName)) {
		errors[errors.length] = "Enter a valid first name.";
	}
	
	if (!reName.test(lastName)) {
		errors[errors.length] = "Enter a valid last name.";
	}
	
	
	
	if (!reEmail.test(email)) {
		errors[errors.length] = "Enter a valid email address.";
	}
	
	if(document.getElementById('userMsg')){
		if(userMsg.length === 0) {
			errors[errors.length] = "Actually write an e-mail.";	
		}
	}
	
	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function reportErrors(errors){
	var msg = "To send an E-mail we need you to...\n";
	for (var i = 0; i<errors.length; i++) {
		var numError = i + 1;
		msg += "\n" + numError + ". " + errors[i];
	}
	alert(msg);
}


