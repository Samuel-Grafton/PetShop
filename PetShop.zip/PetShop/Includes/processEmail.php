<?php
	if (count($_POST)>0){
	 
      	require('class.phpmailer.php');
        $to = "samuel8@twc.com";//To samuel8@twc.com
        $from = $_POST['email'];//email
        $fromName = $_POST['fName'];
		$fromName2 = $_POST['lName'];
        $message = $_POST['usermsg'];
        $host = "mail.twc.com"; // mail.twc.com
		
        $mail = new PHPMailer();
                     
        $mail->IsSMTP(); // send via SMTP
        $mail->Host = $host; //SMTP server
        $mail->SMTPAuth = true;
		$mail->Username = 'samuel8@twc.com';
		$mail->Password = '93652169';
        $mail->From = $from;
        $mail->FromName = $fromName .' '. $fromName2;
        $mail->AddAddress($to);
        $mail->AddReplyTo($from);
         
        $mail->WordWrap = 50; // set word wrap
         
        $mail->Subject  = 'Contacting Incoming';
        $mail->Body = $message;
				
		
        if($mail->Send())
        {
            echo "Message Sent";
        }
        else
        {
             echo "Message Not Sent<br>";
             echo "Mailer Error: " . $mail->ErrorInfo;
        } 
		
	}
?>