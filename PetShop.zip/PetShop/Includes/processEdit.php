<?php
$petEntries = array();
$petEntries['dog']='dog';
$petEntries['cat']='cat';

$dogEntries = array();
$dogEntries['poodle']='poodle';
$dogEntries['pitbull']='pitbull';
$dogEntries['bulldog']='bulldog';
$dogEntries['pekingese']='pekingese';
	
function textEntry($display,$id,$name,$entries,$size=15)
{
	$returnVal = "
	<tr>
		<td>$display:</td>
		<td>
			<input type='text' id='$id' name='$name' size='$size'
			value='" . $entries . "'>";

	$returnVal .= '</td></tr>';

	return $returnVal;
}

function selectEntry($display,$id,$name,$options,$selected=0)
{
	$returnVal = "<tr>
		<td>$display:</td>
		<td>
			<select name='$name' id='$id'>
			<option value='0'>Please select...</option>";
			foreach ($options as $key=>$option)
			{
				if ($key == $selected)
				{
					$returnVal .= "<option value='$key' selected>
								$option</option>";
				}
				else
				{
					$returnVal .= "<option value='$key'>
								$option</option>";
				}
			}
			$returnVal .= "</select>
		</td>
		</tr>";

	return $returnVal;
}

function checkEntry($display,$id,$name,$entries)
{
	$returnVal = "
	<tr>
		<td>$display:</td>
		<td>
			<input type='checkbox' id='$id' name='$name'
			value='" . $entries . "'>";

	$returnVal .= '</td></tr>';

	return $returnVal;
}

$groomingID = $_POST['GroomingID'];

	$query = "SELECT FirstName, LastName, 
			Address, City, State, Zip, PhoneNumber,
			Email, PetType, Breed, PetName,
			NeuteredOrSpayed, PetAge
			FROM grooming
			WHERE GroomingID = $groomingID";
	$result = $db->query($query);
	$_POST = $result->fetch_assoc();
						
	$result->free();
?>