<?php 
	session_start();
	
	$_SESSION['previous'] = basename($_SERVER['PHP_SELF']); 
	
	if (isset($_SESSION['previous'])) {
   if (basename($_SERVER['PHP_SELF']) != $_SESSION['previous']) {
        session_destroy();
		header('Location: index.php');
   }
} elseif(!isset($_SESSION['login']) || $_SESSION['login'] == false) {
		header('Location: index.php');
		session_destroy();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script type="text/javascript" src="Includes/jquery-1.12.0.min.js"></script>
<script>
	$(document).ready(function(){
	$(document.getElementsByName('Delete')).on('click',function(event){
		event.preventDefault();
		var id = $(this).prev('.hidden').val()	
		if(confirm("Delete Request?")){ 
			$.ajax({
        		url : 'Includes/deleteReq.php',
 				
				data: {
					GroomingID : id
				},
				
        		type : 'POST',
  
        		success : function() {
            		alert('Delete Successful.');
        		},
 
        		error : function(xhr, status) {
            		alert('Sorry, there was a problem!');
        		},
 
        		complete : function(xhr, status) {
            		alert('The request is complete!');
        		}
			});
		}
	});
	});
</script>
<title>Untitled Document</title>
</head>
<body>
<div align="center">
<?php
@$db = new mysqli('localhost','root','pwdpwd','pet_shop');
if (mysqli_connect_errno())
{
	echo 'Cannot connect to database: ' . mysqli_connect_error();
}
else
{
	$query = 'SELECT * FROM grooming';
	$result = $db->query($query);
	$numResults = $result->num_rows;

	echo "<h2>$numResults Grooming Requests</h2>";
?>

	<table border="1">
	<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Phone Number</th>
		<th>Email</th>
		<th>Pet Name</th>
	</tr>
<?php
	while ($row = $result->fetch_assoc())
	{
		echo '<tr>';
		echo '<td>' . $row['FirstName'] . '</td>';
		echo '<td>' . $row['LastName'] . '</td>';
		echo '<td>' . $row['PhoneNumber'] . '</td>';
		echo '<td>' . $row['Email'] . '</td>';
		echo '<td align="right">' . $row['PetName'] . '</td>';
		echo '<td><form method="post" action="editForm.php">
				<input type="hidden" name="GroomingID"
					value="' . $row['GroomingID'] . '">
				<input type="submit" name="Editing" value="Edit">
				</form></td>';
		echo '<td><form method="post" action="groomReq.php">
				<input type="hidden" name="GroomingID" class="hidden"
					value="' . $row['GroomingID'] . '">
				<input type="submit" name="Delete" value="Delete">
				</form></td>';
		echo '</tr>';
	}
?>
	</table>
    <a align="right" href='Includes/Logout.php'>Log out</a>
    </div>
<?php
	$result->free();
	$db->close();
}
?>
</body>
</html>