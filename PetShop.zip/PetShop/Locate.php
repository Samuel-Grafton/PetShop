<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation.min.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sandy's Pet Shop</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?> 
	<div id="mapcontainer"></div>
		<script type="text/javascript">
			var directionsDisplay;
			var directionsService = new google.maps.DirectionsService();
			var map;
			var coords;
			var storelocation; 
			
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(locateSuccess, locateFail);
			} 

			function locateSuccess(loc) { 
				var latitude = loc.coords.latitude;
				var longitude = loc.coords.longitude;
					coords = new google.maps.LatLng(latitude, longitude);
					storelocation =  new google.maps.LatLng(latitude + 0.006, longitude - 0.002);	
  					directionsDisplay = new google.maps.DirectionsRenderer();
  				var mapOptions = {
    				zoom:7,
    				center: coords
  				}
  					map = new google.maps.Map(document.getElementById("mapcontainer"), mapOptions);
  					directionsDisplay.setMap(map);
					calcRoute();
				
			}
			
			function calcRoute() {
  				var request = {
   					origin:coords,
    				destination:storelocation,
    				travelMode: google.maps.TravelMode.DRIVING
  				};
  					directionsService.route(request, function(result, status) {
    					if (status == google.maps.DirectionsStatus.OK) {
     						directionsDisplay.setDirections(result);
    					}
  					});
			}
				
		
		
			function locateFail(geoPositionError) {
				alert('An unknown error occurred, sorry');
			} 
			
			google.maps.event.addListener(marker, 'click', function() {
					infowindow.open(map,marker);
				});

			google.maps.event.trigger(marker, 'click');
</script>
<?php require('Includes\Footer.php');?> 
</div>
</div>
</body>
</html>
