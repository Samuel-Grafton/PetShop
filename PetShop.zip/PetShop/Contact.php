<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" rel="stylesheet" href="reset.css">
<link type="text/css" rel="stylesheet" href="foundation.min.css">
<link type="text/css" rel="stylesheet" href="petshop.css">
<script type="text/javascript" src="Includes/Contacttest.js"></script>
<script type="text/javascript" src="Includes/jquery-1.12.0.min.js"></script>
<script>
	$(document).ready(function(){
		$('#Submit').on('click', function(event){
			event.preventDefault();
			var form = document.getElementById('form');
			if(validate(form) === true) {
			var fName = document.getElementById('fName').value;
			var lName = document.getElementById('lName').value;
			var email = document.getElementById('email').value;
			var usermsg = document.getElementById('usermsg').value;
			$.ajax({
        		// the URL for the request
        		url : 'Includes/processEmail.php',
 
       			// the data to send
        		// (will be converted to a query string)
       			data : { 
					fName : fName,  //firstName
					lName : lName, 	//lastName
					email : email,		//eMail
					usermsg : usermsg	//userMsg
					},
 
        		// whether this is a POST or GET request
        		type : 'POST',
  
        		success : function() {
            		alert('The e-mail was sent');
        		},
 
        		error : function(xhr, status) {
            		alert('Sorry, there was a problem!');
        		},
 
        		complete : function(xhr, status) {
            		alert('The request is complete!');
        		}
    		});
			} /* */
		});
	}); 
</script>
<title>Sandy's Pet Shop</title>
</head>
<body>
<div class="bg">
<div id="wrapper">
<?php require('Includes\Header.php');?>
<?php require('Includes\processEmail.php'); ?>
<form method="post" action="Contact.php" id="form">
<fieldset class="contact" id="contact">
	<legend>Contact Info:</legend>
    	<div class="row">
        	<div class="small-12 columns">
				<label for="fName">First Name:</label>
				<input type="text" size="15" name="fName" id="fName" title="First Name">
			</div>
            <div class="small-12 columns">
				<label for="lName">Last Name:</label>
				<input type="text" size="15" name="lName" id="lName" title="Last Name">
			</div>
            <div class="small-12 columns">
        		<label for="email">E-mail:</label>
        		<input type="email" size="20" name="email" id="email" title="E-mail">
        	</div>
            <div class="small-12 columns">
        		<label for="usermsg">Leave a Message</label>
        		<textarea name="usermsg" cols="50" rows="5" id="usermsg" title="Message"></textarea>
       		</div>
            <div class="float-right">
        		<input type="submit" id="Submit" name="Submit" value="Submit">
        	</div>
        </div>
</fieldset>
</form> 
<?php require('Includes\Footer.php');?> 
</div>
</div>
</body>
</html>
